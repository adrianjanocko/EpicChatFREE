---
name: Question
about: Ask a question about the library.
title: 'Minecraft Version: Your Question Title'
labels: question
assignees: ''

---

<!---
To ask us anything, please follow these directions:

1) Please include your Minecraft version in your title:
Example: 1.16.1: How to setup the menus?

2) Try to keep it simple and clear, providing us all information necessary to answer your question. You can use imgur.com to upload images or pastebin.com to upload large text or error traces.

Thank you. Please remove this text and write your actual question below.
-->
